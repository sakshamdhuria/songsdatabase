import org.junit.jupiter.api.Test;
import java.util.Scanner;
import org.junit.jupiter.api.Assertions;

/**
 * Class for all of the JUnit tester methods Tests the FrontendImplementations
 */
public class FrontendDeveloperTests {


  /**
   * JUnit test to test readData() method. Uses the TextUITester class Test to make sure the method
   * provides text-based user interface and error handling for the [R]ead Data command.
   * 
   * @return true if correct implementation, false otherwise
   */
  @Test
  public void testReadData() {
    // Test input
    String input = "R\n./songs.csv\nq\n";
    // Create a new TextUITester object with simulated user input
    TextUITester tester = new TextUITester(input);
    // Create a scanner
    Scanner in = new Scanner(System.in);
    // Create instance of ISCPlaceholder
    IterableSortedCollection<SongInterface> tree1 = new ISCPlaceholder<>();
    // Create a BackendPlaceholder object
    BackendPlaceholder backend = new BackendPlaceholder(tree1);
    // Create a new FrontendImplementations object with the backend and a scanner
    FrontendImplementations frontend = new FrontendImplementations(backend, in);
    // Run through commands
    frontend.runCommandLoop();
    in.close();
    // Check whether the output contains the correct message
    String output = tester.checkOutput();
    Assertions.assertTrue(output.contains("File read successfully."));
  }

  /**
   * JUnit test to test getValues() method Uses the TextUITester class Test to make sure[G]et Songs
   * by Speed BPM command works
   * 
   * @return true if correct implementation, false otherwise
   */
  @Test
  public void testBPMRange() {
    // Test input
    String input = "G\n80\n120\nQ\n";
    // Create a new TextUITester object with simulated user input
    TextUITester tester = new TextUITester(input);
    // Create a scanner
    Scanner in = new Scanner(System.in);
    // Create instance of ISCPlaceholder
    IterableSortedCollection<SongInterface> tree1 = new ISCPlaceholder<>();
    // Create a BackendPlaceholder object
    BackendPlaceholder backend = new BackendPlaceholder(tree1);
    // Create a new FrontendImplementations object with the backend and a scanner
    FrontendImplementations frontend = new FrontendImplementations(backend, in);
    // Run through commands
    frontend.runCommandLoop();
    in.close();
    // Check whether the output contains the correct message
    String output = tester.checkOutput();
    Assertions.assertTrue(output.contains("Songs by Specified Speed BPM: "));

  }

  /**
   * JUnit test to test setFilter() method Uses the TextUITester class Test to make sure the method
   * provides text-based user interface and error handling for the [F]ilter Old Songs (by Max Year)
   * command.
   * 
   * @return true if correct implementation, false otherwise
   */
  @Test
  public void testFilterOldSongs() {
    // Test input
    String input = "F\n2000\nQ\n";
    // Create a new TextUITester object with simulated user input
    TextUITester tester = new TextUITester(input);
    // Create a scanner
    Scanner in = new Scanner(System.in);
    // Create instance of ISCPlaceholder
    IterableSortedCollection<SongInterface> tree1 = new ISCPlaceholder<>();
    // Create a BackendPlaceholder object
    BackendPlaceholder backend = new BackendPlaceholder(tree1);
    // Create a new FrontendImplementations object with the backend and a scanner
    FrontendImplementations frontend = new FrontendImplementations(backend, in);
    // Run through commands
    frontend.runCommandLoop();
    in.close();
    // Check whether the output contains the correct message
    String output = tester.checkOutput();
    Assertions.assertTrue(output.contains("Filtered Songs: "));
  }

  /**
   * JUnit test to test topFive() method Uses the TextUITester class Test to make sure the method
   * provides text-based user interface and error handling for the [D]isplay Five Most Danceable
   * command.
   * 
   * @return true if correct implementation, false otherwise
   */
  @Test
  public void testFiveMostDanceable() {
    // Test input
    String input = "D\nQ\n";
    // Create a new TextUITester object with simulated user input
    TextUITester tester = new TextUITester(input);
    // Create a scanner
    Scanner in = new Scanner(System.in);
    // Create instance of ISCPlaceholder
    IterableSortedCollection<SongInterface> tree1 = new ISCPlaceholder<>();
    // Create a BackendPlaceholder object
    BackendPlaceholder backend = new BackendPlaceholder(tree1);
    // Create a new FrontendImplementations object with the backend and a scanner
    FrontendImplementations frontend = new FrontendImplementations(backend, in);
    // Run through commands
    frontend.runCommandLoop();
    in.close();
    // Check whether the output contains the correct message
    String output = tester.checkOutput();
    Assertions.assertTrue(output.contains("Top 5 Danceable Songs: "));
  }

  /**
   * JUnit test to test when the user inputs the "Q" command "Q" command quits the program Uses
   * TextUITester
   * 
   * @return true if correct implementation, false otherwise
   */
  @Test
  public void testQuitCommand() {
    // Test input
    String input = "Q\n";
    // Create a new TextUITester object with simulated user input
    TextUITester tester = new TextUITester(input);
    // Create a scanner
    Scanner in = new Scanner(System.in);
    // Create instance of ISCPlaceholder
    IterableSortedCollection<SongInterface> tree1 = new ISCPlaceholder<>();
    // Create a BackendPlaceholder object
    BackendPlaceholder backend = new BackendPlaceholder(tree1);
    // Create a new FrontendImplementations object with the backend and a scanner
    FrontendImplementations frontend = new FrontendImplementations(backend, in);
    // Run through commands
    frontend.runCommandLoop();
    in.close();
    // Check whether the output contains the correct message
    String output = tester.checkOutput();
    Assertions.assertTrue(output.contains("Exiting iSongify."));
  }

}
